package com.robotraconteur;

public interface Func3<T1, T2, T3, U> extends java.util.EventListener
{
    U func(T1 p1, T2 p2, T3 p3);
}
