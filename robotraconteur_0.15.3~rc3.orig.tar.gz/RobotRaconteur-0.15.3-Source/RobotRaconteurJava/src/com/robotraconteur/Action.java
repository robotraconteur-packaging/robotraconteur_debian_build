package com.robotraconteur;

public interface Action extends java.util.EventListener
{
    void action();
}
