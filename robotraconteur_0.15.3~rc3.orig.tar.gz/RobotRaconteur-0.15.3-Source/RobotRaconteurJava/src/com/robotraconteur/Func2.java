package com.robotraconteur;

public interface Func2<T1, T2, U> extends java.util.EventListener
{
    U func(T1 p1, T2 p2);
}
