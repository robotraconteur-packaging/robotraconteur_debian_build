package com.robotraconteur;

public interface Action8<T1, T2, T3, T4, T5, T6, T7, T8> extends java.util.EventListener
{
    void action(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6, T7 p7, T8 p8);
}
