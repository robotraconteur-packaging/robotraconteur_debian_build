package com.robotraconteur;

public interface RRNamedArray
{}