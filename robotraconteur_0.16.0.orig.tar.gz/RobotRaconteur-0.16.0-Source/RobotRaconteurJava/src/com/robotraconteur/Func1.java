package com.robotraconteur;

public interface Func1<T1, U> extends java.util.EventListener
{
    U func(T1 p1);
}
