package com.robotraconteur;

public interface Func<U> extends java.util.EventListener
{
    U func();
}
