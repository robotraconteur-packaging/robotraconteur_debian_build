package com.robotraconteur;

public interface RRStructure
{}