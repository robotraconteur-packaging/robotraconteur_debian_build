package com.robotraconteur;

public interface Action5<T1, T2, T3, T4, T5> extends java.util.EventListener
{
    void action(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5);
}
