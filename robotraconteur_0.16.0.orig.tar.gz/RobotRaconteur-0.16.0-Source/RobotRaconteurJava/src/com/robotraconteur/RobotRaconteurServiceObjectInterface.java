package com.robotraconteur;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME) public @interface RobotRaconteurServiceObjectInterface
{}