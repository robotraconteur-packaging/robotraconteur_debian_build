package com.robotraconteur;

public interface Func4<T1, T2, T3, T4, U> extends java.util.EventListener
{
    U func(T1 p1, T2 p2, T3 p3, T4 p4);
}
