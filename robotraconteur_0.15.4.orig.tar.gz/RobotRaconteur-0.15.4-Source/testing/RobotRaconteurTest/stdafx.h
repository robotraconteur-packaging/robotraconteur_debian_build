#include <RobotRaconteur.h>

#include "com__robotraconteur__testing__TestService1_stubskel.h"
#include "com__robotraconteur__testing__TestService2_stubskel.h"
#include "com__robotraconteur__testing__TestService3_stubskel.h"
#include "AsyncMessageTest.h"
#include "MessageSerializationTest.h"
#include "MessageSerializationTest4.h"
#include "MultiDimArrayTest.h"
#include "ServiceTest2.h"
#include "ServiceTestClient.h"
#include "ServiceTestClient.h"
#include "CompareArray.h"

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/range.hpp>
#include <boost/predef/other/endian.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <boost/algorithm/string.hpp>
#include <boost/assign/list_of.hpp>

#pragma once
