package com.robotraconteur;

public interface IRRServiceObject
{
	void rRInitServiceObject(ServerContext context, String service_path);
}