package com.robotraconteur;

public interface Action2<T1, T2> extends java.util.EventListener
{
    void action(T1 p1, T2 p2);
}
