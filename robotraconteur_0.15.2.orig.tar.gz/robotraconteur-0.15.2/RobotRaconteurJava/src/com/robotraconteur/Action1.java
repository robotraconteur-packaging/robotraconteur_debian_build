package com.robotraconteur;

public interface Action1<T1> extends java.util.EventListener
{
    void action(T1 p1);
}
