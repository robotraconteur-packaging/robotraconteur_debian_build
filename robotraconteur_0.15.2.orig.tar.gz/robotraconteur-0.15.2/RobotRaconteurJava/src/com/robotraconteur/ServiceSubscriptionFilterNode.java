package com.robotraconteur;

public class ServiceSubscriptionFilterNode
{
	public NodeID NodeID;
	public String NodeName;
	public String Username;
	public java.util.Map<String,Object> Credentials;
}
