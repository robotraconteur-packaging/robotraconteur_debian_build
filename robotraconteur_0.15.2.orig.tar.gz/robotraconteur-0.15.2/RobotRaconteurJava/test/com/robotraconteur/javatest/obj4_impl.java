package com.robotraconteur.javatest;

import com.robotraconteur.*;
import com.robotraconteur.testing.TestService1.*;
import com.robotraconteur.testing.TestService2.*;
import com.robotraconteur.testing.TestService3.*;

import java.util.*;

public class obj4_impl implements obj4
{
	public String get_s_ind()
	{
		throw new UnsupportedOperationException();
	}
    public void set_s_ind(String value)
	{
		throw new UnsupportedOperationException();
	}
    public int get_i_ind()
	{
		throw new UnsupportedOperationException();
	}		
    public void set_i_ind(int value)
	{
		throw new UnsupportedOperationException();
	}
    public String get_data()
	{
		throw new UnsupportedOperationException();
	}
    public void set_data(String value)
	{
		throw new UnsupportedOperationException();
	}
    public com.robotraconteur.testing.TestService1.sub3 get_o3_1(String ind)
	{
		throw new UnsupportedOperationException();
	}
}