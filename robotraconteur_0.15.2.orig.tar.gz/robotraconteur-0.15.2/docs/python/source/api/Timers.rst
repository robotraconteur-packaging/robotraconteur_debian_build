======
Timers
======

Timer Class
===========

.. autoclass:: RobotRaconteur.Timer()
    :members:

TimerEvent Class
================

.. autoclass:: RobotRaconteur.TimerEvent
    :members:

Rate Class
==========

.. autoclass:: RobotRaconteur.Rate()
    :members:

AutoResetEvent Class
====================

.. autoclass:: RobotRaconteur.AutoResetEvent
    :members: