==================
RobotRaconteurNode
==================
.. autoclass:: RobotRaconteur.RobotRaconteurNode
    :members:
    
    .. attribute:: s
       
       Singleton accessor

       The RobotRaconteurNode singleton can be used when only
       one instance of Robot Raconteur is required in a program.
