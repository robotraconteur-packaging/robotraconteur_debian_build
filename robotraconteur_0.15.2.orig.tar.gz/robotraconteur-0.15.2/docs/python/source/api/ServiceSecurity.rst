================
Service Security
================

AuthenticatedUser Class
=======================

.. autoclass:: RobotRaconteur.AuthenticatedUser
   :members:

ServiceSecurityPolicy Class
===========================

.. autoclass:: RobotRaconteur.ServiceSecurityPolicy
   :members:

NativeUserAuthenticator Class
=============================

.. autoclass:: RobotRaconteur.NativeUserAuthenticator
   :members:

PasswordFileUserAuthenticator Class
===================================

.. autoclass:: RobotRaconteur.PasswordFileUserAuthenticator
   :members: