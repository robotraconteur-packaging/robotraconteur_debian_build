Robot Raconteur Core Python Library {#mainpage}
==============