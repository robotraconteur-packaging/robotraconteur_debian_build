#include <RobotRaconteur.h>

#include "CPPServiceLangGen.h"
#include "CSharpServiceLangGen.h"
#include "JavaServiceLangGen.h"

#include <boost/algorithm/string.hpp>
#include <boost/foreach.hpp>
#include <set>
#include <fstream>
#include <boost/locale.hpp>

#pragma once